package com.cg.quote.exception;

public class UserNameException extends Exception {
	
	public UserNameException(String message) {
		
		System.out.println("User Name Already Exists...Please Try With Another User Name !!!");
	}

}
