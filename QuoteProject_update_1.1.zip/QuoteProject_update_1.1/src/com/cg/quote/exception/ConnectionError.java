package com.cg.quote.exception;

public class ConnectionError extends Exception{
	
	public ConnectionError(String message){
		
		System.out.println("An Error Occured While Connecting To Database");
		
	}

}
