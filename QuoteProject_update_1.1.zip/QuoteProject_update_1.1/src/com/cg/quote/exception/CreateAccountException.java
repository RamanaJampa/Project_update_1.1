package com.cg.quote.exception;

public class CreateAccountException extends Exception{
	
	public CreateAccountException(String message) {
		
		System.out.println("An Error Occured While Creating Account....Please Try After Sometime !!");
	}

}
