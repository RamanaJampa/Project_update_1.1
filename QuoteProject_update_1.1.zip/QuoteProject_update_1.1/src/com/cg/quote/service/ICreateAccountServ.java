package com.cg.quote.service;

import java.io.IOException;

import com.cg.quote.bean.CreateAccount;
import com.cg.quote.bean.NewPolicySchemeBean;

public interface ICreateAccountServ {
	
	public void createAccount(CreateAccount createbean) throws IOException;

	public CreateAccount validateBean(CreateAccount createBean);

	public void createNewScheme(NewPolicySchemeBean newPolicySchemeBean) throws IOException;

}
